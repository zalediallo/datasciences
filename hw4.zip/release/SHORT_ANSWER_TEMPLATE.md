# HW5 Réponses courtes / HW5 Short Answers


**Name:** Votre_Nom / Your_Name

**Matricule \#:** Votre numéro de matricule / Your Student ID

**Veuillez écrire vos réponses courtes ci-dessous et les inclure dans votre soumission de gradescope. / Please write your short answers below and include this as part of your gradescope submission.**

**Le titre du rapport doit être HW5_{Votre_Nom}\_{Matricule_\#} / The title of the report should be HW5_{Your_Name}\_{Matricule_\#}**


## Question 2

## Question 4

## Question 5

## Question 7

## Question 8

## Question 9